///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// manage the viewing of 3D objects within the viewport - camera, projection
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;

	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// Camera object used for viewing and interacting with the scene.
	Camera* g_pCamera = nullptr;

	// Variables used for mouse movement processing.
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// Time between current frame and last frame.
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;

	// False = perspective projection.
	// True = orthographic projection.
	bool bOrthographicProjection = false;

	// False = front camera preset.
	// True = side camera preset.
	bool bSideView = false;

	// Prevents the Tab key from toggling repeatedly while held down.
	bool bTabWasPressed = false;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager* pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;

	g_pCamera = new Camera();

	// Default front-view camera parameters.
	g_pCamera->Position = glm::vec3(0.0f, 3.0f, 8.0f);
	g_pCamera->Front = glm::vec3(0.0f, 0.0f, -1.0f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);

	g_pCamera->Zoom = 60;
	g_pCamera->MovementSpeed = 20;
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;

	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(
	const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL,
		NULL);

	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}

	glfwMakeContextCurrent(window);

	// Capture the mouse inside the display window.
	glfwSetInputMode(
		window,
		GLFW_CURSOR,
		GLFW_CURSOR_DISABLED);

	// Receive mouse movement events.
	glfwSetCursorPosCallback(
		window,
		&ViewManager::Mouse_Position_Callback);

	// Receive mouse wheel events for movement speed adjustment.
	glfwSetScrollCallback(
		window,
		&ViewManager::Mouse_Scroll_Callback);

	// Enable blending for transparent rendering.
	glEnable(GL_BLEND);
	glBlendFunc(
		GL_SRC_ALPHA,
		GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return window;
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active display window.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(
	GLFWwindow* window,
	double xMousePos,
	double yMousePos)
{
	// Record the initial mouse position.
	if (gFirstMouse)
	{
		gLastX = static_cast<float>(xMousePos);
		gLastY = static_cast<float>(yMousePos);
		gFirstMouse = false;
	}

	// Calculate mouse movement offsets.
	float xOffset =
		static_cast<float>(xMousePos) - gLastX;

	float yOffset =
		gLastY - static_cast<float>(yMousePos);

	// Store the current mouse position for the next frame.
	gLastX = static_cast<float>(xMousePos);
	gLastY = static_cast<float>(yMousePos);

	// Rotate the camera according to mouse movement.
	g_pCamera->ProcessMouseMovement(
		xOffset,
		yOffset);
}

/***********************************************************
 *  Mouse_Scroll_Callback()
 *
 *  Adjusts the camera movement speed when the mouse wheel
 *  is scrolled.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(
	GLFWwindow* window,
	double xOffset,
	double yOffset)
{
	// Scroll up to increase movement speed.
	// Scroll down to decrease movement speed.
	g_pCamera->MovementSpeed +=
		static_cast<float>(yOffset) * 2.0f;

	// Keep movement speed within a practical range.
	if (g_pCamera->MovementSpeed < 1.0f)
	{
		g_pCamera->MovementSpeed = 1.0f;
	}

	if (g_pCamera->MovementSpeed > 50.0f)
	{
		g_pCamera->MovementSpeed = 50.0f;
	}
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  This method processes keyboard input for camera movement,
 *  projection changes, and camera-view presets.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// Close the window when Escape is pressed.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(
			m_pWindow,
			true);
	}

	// If the camera object is unavailable, stop processing input.
	if (NULL == g_pCamera)
	{
		return;
	}

	/********************************************************/
	// WASD CAMERA MOVEMENT
	/********************************************************/

	// Move forward.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			FORWARD,
			gDeltaTime);
	}

	// Move backward.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			BACKWARD,
			gDeltaTime);
	}

	// Move left.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			LEFT,
			gDeltaTime);
	}

	// Move right.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			RIGHT,
			gDeltaTime);
	}

	/********************************************************/
	// VERTICAL CAMERA MOVEMENT
	/********************************************************/

	// Move upward with Q.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->Position.y +=
			g_pCamera->MovementSpeed * gDeltaTime;
	}

	// Move downward with E.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->Position.y -=
			g_pCamera->MovementSpeed * gDeltaTime;
	}

	/********************************************************/
	// PROJECTION CONTROLS
	/********************************************************/

	// P switches to perspective projection.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_P) == GLFW_PRESS)
	{
		bOrthographicProjection = false;
	}

	// O switches to orthographic projection.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_O) == GLFW_PRESS)
	{
		bOrthographicProjection = true;
	}

	/********************************************************/
	// TAB CAMERA PRESETS
	/********************************************************/

	// Tab switches between front and side camera presets.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_TAB) == GLFW_PRESS)
	{
		if (!bTabWasPressed)
		{
			bSideView = !bSideView;

			if (bSideView)
			{
				// Side-view preset.
				g_pCamera->Position =
					glm::vec3(10.0f, 3.0f, 0.0f);

				// Synchronize mouse-look orientation.
				g_pCamera->Yaw = 180.0f;
				g_pCamera->Pitch = -2.86f;

				g_pCamera->Front =
					glm::normalize(
						glm::vec3(0.0f, 2.5f, 0.0f) -
						g_pCamera->Position);
			}
			else
			{
				// Front-view preset.
				g_pCamera->Position =
					glm::vec3(0.0f, 3.0f, 8.0f);

				// Synchronize mouse-look orientation.
				g_pCamera->Yaw = -90.0f;
				g_pCamera->Pitch = -3.58f;

				g_pCamera->Front =
					glm::normalize(
						glm::vec3(0.0f, 2.5f, 0.0f) -
						g_pCamera->Position);
			}

			bTabWasPressed = true;
		}
	}
	else
	{
		bTabWasPressed = false;
	}
}
/***********************************************************
 *  PrepareSceneView()
 *
 *  This method prepares the view and projection matrices
 *  used to display the 3D scene.
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// Calculate time elapsed since the previous frame.
	float currentFrame =
		static_cast<float>(glfwGetTime());

	gDeltaTime =
		currentFrame - gLastFrame;

	gLastFrame =
		currentFrame;

	// Process keyboard controls.
	ProcessKeyboardEvents();

	// Always use the Camera object's current state.
	// This allows WASD, Q/E, mouse movement, and Tab presets
	// to work together.
	view =
		g_pCamera->GetViewMatrix();

	// Select perspective or orthographic projection.
	if (bOrthographicProjection)
	{
		projection =
			glm::ortho(
				-10.0f,
				10.0f,
				-8.0f,
				8.0f,
				0.1f,
				100.0f);
	}
	else
	{
		projection =
			glm::perspective(
				glm::radians(
					g_pCamera->Zoom),
				(GLfloat)WINDOW_WIDTH /
				(GLfloat)WINDOW_HEIGHT,
				0.1f,
				100.0f);
	}

	// Send camera matrices and camera position to the shader.
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(
			g_ViewName,
			view);

		m_pShaderManager->setMat4Value(
			g_ProjectionName,
			projection);

		m_pShaderManager->setVec3Value(
			"viewPosition",
			g_pCamera->Position);
	}
}